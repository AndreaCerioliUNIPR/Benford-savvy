function out = dksone(x,xcdf)
    %{
        clear all;
        load examgrades;
        x = grades(:,1);
        xcdf=cdf('tlocationscale',x,75,10,1);
        out = dksone(x,xcdf);
    %}
    test_cdf = [x(:),xcdf(:)];
    [h,pu,ksstatu,cv] = kstest(x,'CDF',test_cdf,'Tail','unequal');
    [h,pl,ksstatl,cv] = kstest(x,'CDF',test_cdf,'Tail','larger');
    [h,ps,ksstats,cv] = kstest(x,'CDF',test_cdf,'Tail','smaller');
    out = [ksstatu,ksstatl,ksstats,0,0,pu];

end